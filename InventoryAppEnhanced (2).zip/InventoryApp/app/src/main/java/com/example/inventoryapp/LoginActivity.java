package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity handles user authentication.
 * Users can log in, navigate to sign up, or reset their password.
 */
public class LoginActivity extends AppCompatActivity {

    // UI elements
    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private TextView createAccountLink, forgotPasswordLink;

    // Helper class for database operations
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // display activity_login.xml
        setContentView(R.layout.activity_login);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Link UI components and their corresponding layout elements
        usernameEditText = findViewById(R.id.enterUsername);
        passwordEditText = findViewById(R.id.enterPassword);
        loginButton = findViewById(R.id.btnSignIn);
        createAccountLink = findViewById(R.id.create_account_link);
        forgotPasswordLink = findViewById(R.id.forgot_password_link);
        // Handle user actions
        loginButton.setOnClickListener(v -> handleLogin());
        createAccountLink.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, SignUpActivity.class)));
        forgotPasswordLink.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class)));
    }

    /**
     * Handles the login logic:
     * - Validates input fields
     * - Verifies user credentials in the database
     * - Stores session details if login succeeds
     */
    private void handleLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Ensure both fields are filled
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Check if the user exists
        Cursor userCursor = db.query("users", null, "username=?", new String[]{username}, null, null, null);
        if (userCursor != null && userCursor.getCount() == 0) {
            // User does not exist
            Toast.makeText(this, "User does not exist", Toast.LENGTH_SHORT).show();
            userCursor.close();
            return;
        }

        // Validate credentials
        Cursor cursor = db.query("users", null, "username=? AND password=?", new String[]{username, password}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Extract user role and business ID for session tracking
            String role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
            String businessId = cursor.getString(cursor.getColumnIndexOrThrow("business_id"));

            // Save user session info in SharedPreferences
            android.content.SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            android.content.SharedPreferences.Editor editor = prefs.edit();
            editor.putString("username", username);
            editor.putString("role", role);
            editor.putString("business_id", businessId);
            editor.apply();

            cursor.close();

            Toast.makeText(this, "Login successful as " + role, Toast.LENGTH_SHORT).show();
            // Redirect to inventory screen
            startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
            finish();
        } else {
            // if credentials incorrect
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}
