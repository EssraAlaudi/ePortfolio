package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// SmsPermissionActivity handles requesting SMS permission before launching the inventory screen
public class SmsPermissionActivity extends AppCompatActivity {
    // Constant used to identify the permission request result
    private static final int REQUEST_CODE_SEND_SMS = 1;
    // To track whether SMS permission is granted
    private boolean isSmsPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Check if SEND_SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // If not, request it from the user
            requestSmsPermission();
        } else {
            // If granted, proceed to inventory screen
            isSmsPermissionGranted = true; // Permission already granted
            navigateToInventoryScreen(); // Proceed to the main inventory screen
        }
    }

    /**
     * Requests SMS permission using a dialog that explains why it's needed.
     */
    private void requestSmsPermission() {
        new AlertDialog.Builder(this)
                .setMessage("We need permission to send SMS notifications for low inventory alerts.")
                // button to grant permission
                .setPositiveButton("Grant Permission", (dialog, which) -> ActivityCompat.requestPermissions(
                        SmsPermissionActivity.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_CODE_SEND_SMS
                ))
                // Button to deny
                .setNegativeButton("No Thanks", (dialog, which) -> navigateToInventoryScreen())
                .show();
    }

    /**
     * Handles the result of the SMS permission request.
     * Navigates to the inventory screen regardless of the outcome.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Handle result of SEND_SMS request
        if (requestCode == REQUEST_CODE_SEND_SMS) {
            isSmsPermissionGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            // Notify user
            String message = isSmsPermissionGranted
                    ? "Permission granted for SMS notifications."
                    : "Permission denied. SMS notifications will be disabled.";
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

            navigateToInventoryScreen();
        }
    }

    /**
     * Proceeds to the main InventoryActivity, passing along whether SMS permission was granted.
     */
    private void navigateToInventoryScreen() {
        Intent intent = new Intent(SmsPermissionActivity.this, InventoryActivity.class);
        intent.putExtra("isSmsPermissionGranted", isSmsPermissionGranted);
        startActivity(intent);
        finish();
    }
}



