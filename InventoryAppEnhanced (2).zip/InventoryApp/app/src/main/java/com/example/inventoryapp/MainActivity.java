package com.example.inventoryapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;

// MainActivity handles SMS permission request logic before allowing users to proceed to the inventory screen
public class MainActivity extends AppCompatActivity {

    // Request code used to identify SMS permission request
    private static final int REQUEST_CODE_SEND_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // display activity_sms.xml
        setContentView(R.layout.activity_sms);
        // initialize button for granting permission
        Button requestPermissionButton = findViewById(R.id.grant_permission_button);

        // Set up the button click to show the permission dialog
        requestPermissionButton.setOnClickListener(v -> {
            showPermissionRequestDialog();
        });
    }

    /**
     * Displays a dialog prompting the user to grant SMS permission.
     * If accepted, the system permission dialog will be shown.
     */
    private void showPermissionRequestDialog() {
        // Ask user for permission
        new AlertDialog.Builder(this)
                .setTitle("Permission Needed")
                .setMessage("We need permission to send SMS notifications like low inventory alerts or upcoming events.")
                .setPositiveButton("Grant Permission", new DialogInterface.OnClickListener() {
                    // when user grants permission
                    public void onClick(DialogInterface dialog, int which) {
                        // Request SEND_SMS permission from the user
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.SEND_SMS},
                                REQUEST_CODE_SEND_SMS);
                    }
                })
                // When user denies permission
                .setNegativeButton("No Thanks", null)
                .show();
    }
    // When user responds to the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_SEND_SMS) {
            // check if permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Notify the user that permission was granted
                Toast.makeText(this, "Permission granted.", Toast.LENGTH_SHORT).show();
                // move on to inventory screen
                Intent intent = new Intent(MainActivity.this,InventoryActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Notify the user that permission was denied
                Toast.makeText(this, "Permission denied. You can enable SMS permission in app settings.", Toast.LENGTH_LONG).show();
            }
        }
    }
}

