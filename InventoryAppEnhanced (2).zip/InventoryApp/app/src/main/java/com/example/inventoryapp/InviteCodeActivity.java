package com.example.inventoryapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.UUID;

// Activity for invite code functionality
public class InviteCodeActivity extends AppCompatActivity {


    // Database helper to manage SQLite operations
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_code);
        // Enable the action bar's back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Reference UI components
        Spinner roleSpinner = findViewById(R.id.spinner_role);
        Button generateButton = findViewById(R.id.btn_generate_code);
        TextView generatedCodeView = findViewById(R.id.text_generated_code);

        // Populate spinner with roles from resources
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roleSpinner.setAdapter(adapter);

        // "Generate Code" button handling
        generateButton.setOnClickListener(v -> {
            // Get selected role from spinner
            String selectedRole = roleSpinner.getSelectedItem().toString();
            // Generate a random 8-character invite code
            String generatedCode = UUID.randomUUID().toString().substring(0, 8);
            // Retrieve business ID from shared preferences
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String businessId = prefs.getString("business_id", "");
            // Attempt to insert the generated invite code into the database
            boolean success = dbHelper.insertInviteCode(generatedCode, selectedRole, businessId);

            // Show result to user
            if (success) {
                generatedCodeView.setText("Code: " + generatedCode);
                // if successful
                Toast.makeText(this, "Invite code generated!", Toast.LENGTH_SHORT).show();
            } else {
                //if unsuccessful
                Toast.makeText(this, "Failed to generate code", Toast.LENGTH_SHORT).show();
            }
        });
        }
    // Handle the action bar back button press
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Closes the activity and goes back
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

