package com.example.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper manages the SQLite database for the inventory app.
 * It handles creation, upgrading, and CRUD operations for users, inventory items, and invite codes.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 8;

    // Inventory table and columns
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "id";
    private static final String COLUMN_ITEM_NAME = "name";
    private static final String COLUMN_ITEM_QUANTITY = "quantity";

    // Constructor - initializes the database helper
    public DatabaseHelper(android.content.Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    // Called when the database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, role TEXT, business_id TEXT)");
        // Create inventory table
        db.execSQL("CREATE TABLE inventory (id TEXT PRIMARY KEY, name TEXT, quantity INTEGER, business_id TEXT)");
        // Create invite_codes table
        db.execSQL("CREATE TABLE invite_codes (code TEXT PRIMARY KEY, role TEXT, business_id TEXT)");
    }

    // Called when the database version is updated
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables and recreate them
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");
        db.execSQL("DROP TABLE IF EXISTS invite_codes");
        onCreate(db);
    }

    // Adds an inventory item with businessId
    public boolean addInventoryItem(String id, String name, int quantity, String businessId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", id);
        values.put("name", name);
        values.put("quantity", quantity);
        values.put("business_id", businessId);

        long result = db.insert("inventory", null, values);
        return result != -1;
    }

    // Deletes an inventory item by ID
    public boolean deleteInventoryItem(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + "=?", new String[]{id});
        return rowsAffected > 0; // Return true if any rows were deleted
    }

    // Get all inventory items
    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem(
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY))
                );
                items.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return items;
    }
    // Retrieves inventory items filtered by business ID
    public List<InventoryItem> getInventoryItemsForBusiness(String businessId) {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query("inventory", null, "business_id=?", new String[]{businessId}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem(
                        cursor.getString(cursor.getColumnIndexOrThrow("id")),
                        cursor.getString(cursor.getColumnIndexOrThrow("name")),
                        cursor.getInt(cursor.getColumnIndexOrThrow("quantity"))
                );
                items.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return items;
    }

    /**
     * InventoryItem represents a single item in the inventory.
     */
    public static class InventoryItem {
        private final String id;
        private final String name;
        private final int quantity;

        public InventoryItem(String id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }
        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }
    }
    // Adds a new user to the database
    public boolean addUser(String username, String password, String role, String businessId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        values.put("role", role);
        values.put("business_id", businessId);

        long result = db.insert("users", null, values);
        return result != -1;
    }
    // Inserts a new invite code
    public boolean insertInviteCode(String code, String role, String businessId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("code", code);
        values.put("role", role);
        values.put("business_id", businessId);
        long result = db.insert("invite_codes", null, values);
        return result != -1;
    }
    // Gets invite code details from the database
    public Cursor getInviteCodeDetails(String code) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("invite_codes", null, "code=?", new String[]{code}, null, null, null);
    }
    // Deletes invite code after use
    public void deleteInviteCode(String code) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("invite_codes", "code=?", new String[]{code});
    }



}
