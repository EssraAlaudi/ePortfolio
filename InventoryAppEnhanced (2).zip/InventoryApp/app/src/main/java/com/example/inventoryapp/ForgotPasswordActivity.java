package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


/**
 * Activity that allows users to reset their password if they forgot it.
 */

public class ForgotPasswordActivity extends AppCompatActivity {

    // UI elements
    private EditText usernameEditText, newPasswordEditText;
    private Button resetPasswordButton;
    private TextView backToLoginLink;
    private DatabaseHelper dbHelper;


    /**
     * Initializes the forgot password screen and sets up event handlers.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //display activity_forgot_password.xml
        setContentView(R.layout.activity_forgot_password);

        dbHelper = new DatabaseHelper(this); // Initialize database

        // Connect UI components and their corresponding layout elements
        usernameEditText = findViewById(R.id.username);
        newPasswordEditText = findViewById(R.id.newPassword);
        resetPasswordButton = findViewById(R.id.resetPasswordButton);
        backToLoginLink = findViewById(R.id.back_to_login_link);

        // Handle password reset when button is clicked
        resetPasswordButton.setOnClickListener(v -> handleResetPassword());

        // Navigate back to login screen
        backToLoginLink.setOnClickListener(v -> {
            Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Handles the password reset logic.
     * Validates input and updates the password in the database.
     */
    private void handleResetPassword() {
        String username = usernameEditText.getText().toString();
        String newPassword = newPasswordEditText.getText().toString();

        // Validate that fields are not empty
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(newPassword)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        // Prepare to update user's password in the database
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("password", newPassword);

        // Execute update query where username matches
        int rowsAffected = db.update("users", values, "username=?", new String[]{username});

        if (rowsAffected > 0) {
            // if password reset successful, notify user and redirect to login
            Toast.makeText(this, "Password reset successful!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(ForgotPasswordActivity.this, LoginActivity.class));
            finish();
        } else {
            // if username does not exist, notify user
            Toast.makeText(this, "Error: Username not found", Toast.LENGTH_SHORT).show();
        }
    }
}

