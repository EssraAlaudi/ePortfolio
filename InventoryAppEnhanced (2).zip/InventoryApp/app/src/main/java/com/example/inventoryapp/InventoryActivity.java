package com.example.inventoryapp;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;

import java.util.List;



// InventoryActivity handles the inventory screen UI and logic for both Admin and Staff users
public class InventoryActivity extends AppCompatActivity {
    // Database helper to access and manage SQLite database
    private DatabaseHelper dbHelper;

    // User role and business ID retrieved from shared preferences
    private String role;
    private String businessId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Retrieve user role and business ID from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        role = prefs.getString("role", "");
        businessId = prefs.getString("business_id", "");

        // Populate the inventory items when the activity starts
        populateInventoryTable();

        // Reference the buttons
        Button addItemButton = findViewById(R.id.addItemButton);
        Button deleteItemButton = findViewById(R.id.deleteItemButton);
        ImageView inviteCodeButton = findViewById(R.id.btnInviteCode);

        // Show or hide admin controls based on user role/permissions
        if (role.equals("Admin")) {
            addItemButton.setVisibility(View.VISIBLE);
            deleteItemButton.setVisibility(View.VISIBLE);
            inviteCodeButton.setVisibility(View.VISIBLE);

            addItemButton.setOnClickListener(v -> showAddItemDialog());
            deleteItemButton.setOnClickListener(v -> showDeleteItemDialog());
            inviteCodeButton.setOnClickListener(v ->
                    startActivity(new Intent(InventoryActivity.this, InviteCodeActivity.class))
            );
        } else {
            // Hide these features for Staff
            addItemButton.setVisibility(View.GONE);
            deleteItemButton.setVisibility(View.GONE);
            inviteCodeButton.setVisibility(View.GONE);
        }

        // Search functionality: filter visible rows based on query
        EditText searchBox = findViewById(R.id.search_box);
        TableLayout inventoryTable = findViewById(R.id.inventory_table);

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().toLowerCase();

                for (int i = 1; i < inventoryTable.getChildCount(); i++) {
                    TableRow row = (TableRow) inventoryTable.getChildAt(i);
                    EditText itemIdView = (EditText) row.getChildAt(0);
                    String itemId = itemIdView.getText().toString().toLowerCase();

                    row.setVisibility(itemId.contains(query) ? View.VISIBLE : View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // Populates inventory table with items from database
    private void populateInventoryTable() {
        TableLayout tableLayout = findViewById(R.id.inventory_table);
        tableLayout.removeAllViews();

        // Create header row
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));

        TextView headerItemId = new TextView(this);
        headerItemId.setText("Item ID");
        headerItemId.setTextSize(18);
        headerItemId.setPadding(16, 16, 16, 16);
        headerItemId.setGravity(Gravity.CENTER);
        headerItemId.setBackgroundResource(R.drawable.cell_border);

        TextView headerQuantity = new TextView(this);
        headerQuantity.setText("Quantity");
        headerQuantity.setTextSize(18);
        headerQuantity.setPadding(16, 16, 16, 16);
        headerQuantity.setGravity(Gravity.CENTER);
        headerQuantity.setBackgroundResource(R.drawable.cell_border);

        headerRow.addView(headerItemId);
        headerRow.addView(headerQuantity);
        tableLayout.addView(headerRow);

        // Add existing items from DB
        List<DatabaseHelper.InventoryItem> items = dbHelper.getInventoryItemsForBusiness(businessId);
        for (DatabaseHelper.InventoryItem item : items) {
            TableRow row = new TableRow(this);

            EditText itemIdView = new EditText(this);
            itemIdView.setText(item.getId());
            itemIdView.setTextSize(16);
            itemIdView.setPadding(16, 16, 16, 16);
            itemIdView.setGravity(Gravity.CENTER);
            itemIdView.setBackgroundResource(R.drawable.cell_border);

            EditText quantityView = new EditText(this);
            quantityView.setText(String.valueOf(item.getQuantity()));
            quantityView.setTextSize(16);
            quantityView.setPadding(16, 16, 16, 16);
            quantityView.setGravity(Gravity.CENTER);
            quantityView.setBackgroundResource(R.drawable.cell_border);

            // Disable editing Item ID for Staff
            if (!role.equals("Admin")) {
                itemIdView.setFocusable(false);
                itemIdView.setCursorVisible(false);
                itemIdView.setKeyListener(null);
            }
            row.addView(itemIdView);
            row.addView(quantityView);
            tableLayout.addView(row);
        }

        // low-stock notification if item quantity is less than 5
        for (DatabaseHelper.InventoryItem item : items) {
            if (item.getQuantity() < 5) {
                checkLowStockAndNotify(item.getName(), item.getQuantity());
            }
        }

        // Add empty editable rows
        for (int i = 0; i < 30; i++) {
            TableRow emptyRow = new TableRow(this);

            EditText emptyItemId = new EditText(this);
            emptyItemId.setHint("");
            emptyItemId.setTextSize(16);
            emptyItemId.setPadding(16, 16, 16, 16);
            emptyItemId.setGravity(Gravity.CENTER);
            emptyItemId.setBackgroundResource(R.drawable.cell_border);

            EditText emptyQuantity = new EditText(this);
            emptyQuantity.setHint("");
            emptyQuantity.setTextSize(16);
            emptyQuantity.setPadding(16, 16, 16, 16);
            emptyQuantity.setGravity(Gravity.CENTER);
            emptyQuantity.setBackgroundResource(R.drawable.cell_border);

            emptyRow.addView(emptyItemId);
            emptyRow.addView(emptyQuantity);
            tableLayout.addView(emptyRow);
        }
    }


    // Sends SMS notification to phone number
    private void sendSmsNotification(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "1234567890";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low stock alert sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Checks inventory quantity and triggers notification if stock is low
    private void checkLowStockAndNotify(String itemName, int itemStock) {
        String message = "Low stock alert! " + itemName + " has only " + itemStock + " items left.";
        boolean isSmsPermissionGranted = getIntent().getBooleanExtra("isSmsPermissionGranted", false);
        if (isSmsPermissionGranted) {
            sendSmsNotification(message);
        } else {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }

    // Displays dialog to add a new item to inventory
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        EditText itemIdEditText = dialogView.findViewById(R.id.item_name);
        EditText itemNameEditText = dialogView.findViewById(R.id.item_name);
        EditText itemQuantityEditText = dialogView.findViewById(R.id.item_quantity);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemId = itemIdEditText.getText().toString().trim();
            String itemName = itemNameEditText.getText().toString().trim();
            String itemQuantityStr = itemQuantityEditText.getText().toString().trim();

            if (TextUtils.isEmpty(itemId) || TextUtils.isEmpty(itemName) || TextUtils.isEmpty(itemQuantityStr)) {
                Toast.makeText(this, "Please enter Item ID, Name, and Quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int itemQuantity = Integer.parseInt(itemQuantityStr);

            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String businessId = prefs.getString("business_id", "");

            if (dbHelper.addInventoryItem(itemId, itemName, itemQuantity, businessId)) {
                Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                populateInventoryTable();
            } else {
                Toast.makeText(this, "Failed to add item. Duplicate ID?", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    // Displays dialog to delete an item by ID
    private void showDeleteItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Item");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_delete_item, null);
        builder.setView(dialogView);

        EditText itemIdEditText = dialogView.findViewById(R.id.item_id);

        builder.setPositiveButton("Delete", (dialog, which) -> {
            String itemId = itemIdEditText.getText().toString().trim();

            if (TextUtils.isEmpty(itemId)) {
                Toast.makeText(this, "Please enter an Item ID", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.deleteInventoryItem(itemId)) {
                Toast.makeText(this, "Item deleted successfully!", Toast.LENGTH_SHORT).show();
                populateInventoryTable();
            } else {
                Toast.makeText(this, "Failed to delete item. ID not found.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }
}
