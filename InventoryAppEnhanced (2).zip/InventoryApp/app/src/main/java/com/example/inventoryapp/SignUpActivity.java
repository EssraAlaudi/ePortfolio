package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * SignUpActivity handles the user registration screen logic.
 * Users can sign up either as Admins (with no invite code) or Staff (with a valid invite code).
 */
public class SignUpActivity extends AppCompatActivity {

    // Invite codes mapped to roles
    private static final String ADMIN_INVITE_CODE = "ADMIN123";
    private static final String STAFF_INVITE_CODE = "STAFF123";

    // UI components
    private EditText usernameEditText, passwordEditText;
    private Button createAccountButton;
    private TextView backToLoginLink;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // display activity_signup.xml
        setContentView(R.layout.activity_signup);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

       // UI components and their corresponding layout elements
        usernameEditText = findViewById(R.id.crtUsername);
        passwordEditText = findViewById(R.id.crtPassword);
        createAccountButton = findViewById(R.id.btnCreateAcc);
        backToLoginLink = findViewById(R.id.sign_in_link);

        // Set up button actions
        createAccountButton.setOnClickListener(v -> handleSignUp());
        backToLoginLink.setOnClickListener(v -> startActivity(new Intent(SignUpActivity.this, LoginActivity.class)));
    }

    /**
     * Handles user sign-up logic.
     * Validates input and determines role based on invite code.
     */
    private void handleSignUp() {
        // Read and trim user input
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Get invite code
        EditText inviteCodeEditText = findViewById(R.id.crtInviteCode);
        String inviteCode = inviteCodeEditText.getText().toString().trim();

        // Validate that all required fields are filled
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String role;
        String businessId;

        if (inviteCode.isEmpty()) {
            // No invite code → register as Admin
            role = "Admin";
            businessId = username;
        } else {
            // Validate invite code from the database
            Cursor cursor = dbHelper.getInviteCodeDetails(inviteCode);
            if (cursor != null && cursor.moveToFirst()) {
                // Assign role and business ID from invite code
                role = cursor.getString(cursor.getColumnIndexOrThrow("role"));
                businessId = cursor.getString(cursor.getColumnIndexOrThrow("business_id"));
                cursor.close();

                // delete code after use
                dbHelper.deleteInviteCode(inviteCode);
            } else {
                Toast.makeText(this, "Invalid invite code", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        // Attempt to save the new user into the database
        boolean result = dbHelper.addUser(username, password, role, businessId);
        if (result) {
            //if successful notify user
            Toast.makeText(this, "Account created as " + role, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            finish();
        } else {
            // if unsuccessful notify user
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
        }
    }

}
