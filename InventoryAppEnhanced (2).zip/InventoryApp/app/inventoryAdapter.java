package com.example.inventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class InventoryAdapter extends CursorAdapter {

    public InventoryAdapter(Cursor cursor) {
        super(cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        // Inflate the item view
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        // Bind data to each item
        TextView itemId = view.findViewById(R.id.item_id);
        TextView itemName = view.findViewById(R.id.item_name);
        TextView itemQuantity = view.findViewById(R.id.item_quantity);

        int id = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_ID));
        String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_NAME));
        int quantity = cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_ITEM_QUANTITY));

        itemId.setText(String.valueOf(id));
        itemName.setText(name);
        itemQuantity.setText(String.valueOf(quantity));
    }

    // Method to update the cursor when data is updated
    public void swapCursor(Cursor newCursor) {
        super.swapCursor(newCursor);
        notifyDataSetChanged();
    }
}
