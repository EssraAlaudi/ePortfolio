import numpy as np

class GameExperience(object):
    
    def __init__(self, model, max_memory=100, discount=0.95):

        self.model = model
        self.max_memory = max_memory
        self.discount = discount
        self.memory = list()   # List of stored episodes
        self.priorities = list()  #track priority for each episode
        self.num_actions = model.output_shape[-1] # Number of possible actions
    
    def remember(self, episode):
        # episode = [envstate, action, reward, envstate_next, game_over]
        self.memory.append(episode)
        self.priorities.append(1.0)  #start with default high priority

     # Trim memory if it exceeds maximum size
        if len(self.memory) > self.max_memory:
            del self.memory[0]
            del self.priorities[0]

    def predict(self, envstate):
        return self.model.predict(envstate)[0]
        
    def get_data(self, data_size=10):
    env_size = self.memory[0][0].shape[1]
    mem_size = len(self.memory)
    data_size = min(mem_size, data_size)

    inputs = np.zeros((data_size, env_size))
    targets = np.zeros((data_size, self.num_actions))

    # Convert priorities to probability distribution
    priority_sum = np.sum(self.priorities)
    probabilities = np.array(self.priorities) / priority_sum
     # Sample experience indices based on priority distribution
    sampled_indices = np.random.choice(range(mem_size), size=data_size, replace=False, p=probabilities)

    for i, j in enumerate(sampled_indices):
        envstate, action, reward, envstate_next, game_over = self.memory[j]
        inputs[i] = envstate
        targets[i] = self.predict(envstate)
        
       # Compute the target Q-value
        Q_sa = np.max(self.predict(envstate_next))  # Max Q-value of next state
        if game_over:
            targets[i, action] = reward # No future rewards if game is over
        else:
            targets[i, action] = reward + self.discount * Q_sa # Bellman update

        # Update priority based on squared TD error
        predicted = self.predict(envstate)[action]
        td_error = abs(targets[i, action] - predicted)
        self.priorities[j] = td_error ** 2 + 1e-5  # Add epsilon to avoid zero-probability

    # Apply decay to all priorities
    self.priorities = [p * 0.995 for p in self.priorities]

    return inputs, targets


