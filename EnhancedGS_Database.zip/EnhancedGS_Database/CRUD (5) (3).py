from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """
    
    # initializing the MongoClient
    def __init__(self, user, password, host, port, db_name, collection_name):
        
        # connection variables
        self.user = 'aacuser'
        self.password = 'SNHU2024'
        self.host = 'nv-desktop-services.apporto.com'
        self.port = '32397'
        self.db_name = 'AAC'
        self.collection_name ='animals'
        
        # initialize connection
        self.client = MongoClient(f'mongodb://{self.user}:{self.password}@{self.host}:{self.port}')
        self.database = self.client[self.db_name]
        self.collection = self.database[self.collection_name]
        
         # create method
    def create(self, data):
        # if data is given
        if data is not None:
            try:
                # insert the data into the collection
                self.collection.insert_one(data)
                # return true if sccessful 
                return True
            # error handling
            except Exception as e:
                print(f"Error {e}")
                return False
        # if no data is given
        else:
            print("Nothing to save, because data parameter is empty")
            return False
        
    # read method
    def read(self, query=None):
        # if query is not given
        if query is None:
            # empty query
            query = {}
        try:
            # query the collection 
            cursor = self.collection.find(query)
            # convert the cursor into a list 
            result = list(cursor)
            # return result if found else return an empty list 
            return result if result else []
        # error handling 
        except Exception as e:
            print(f"Error {e}")
            return []
        
    # update method
    def update(self, query, update_data):
        try:
            # updates documents 
            result = self.collection.update_many(query, {'$set': update_data})
            # return updated count 
            return result.modified_count
        # error handling 
        except Exception as e:
            print(f"Error {e}")
            return 0 
    # delete method 
    def delete (self, query):
        try: 
            # deletes documents 
            result = self.collection.delete_many(query)
            # return deleted count 
            return result.deleted_count
        # error handling 
        except Exception as e: 
            print (f"Error {e}")
            return 0 
            
            