const express = require('express'); // Import the Express framework
const mongoose = require('mongoose');  // Import Mongoose for MongoDB interaction
const cors = require('cors'); // Import CORS to allow cross-origin requests

const app = express();   // Initialize the Express app
const PORT = 3000; // Define the server port

app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON bodies in requests

// Connect to MongoDB Atlas
mongoose.connect('mongodb://aacuser:SNHU2024@nv-desktop-services.apporto.com:32397/AAC', {
    useNewUrlParser: true, // Use new URL parser
    useUnifiedTopology: true,  // Use new server discovery (legacy config)
})
.then(() => console.log('Connected to SNHU MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

// Define Mongoose Schema and Model
const animalSchema = new mongoose.Schema({}, { strict: false });
const Animal = mongoose.model('Animal', animalSchema, 'animals');

// GET all animals or filtered search
app.get('/animals', async (req, res) => {
    try {
        const filter = {}; // Default: no filter
 
        if (req.query.breed) {
             // If breed is provided, use case-insensitive regex to match
            filter.breed = { $regex: req.query.breed, $options: 'i' };
        }

          // Query the database with filter and limit results to 100
        const animals = await Animal.find(filter).limit(100);
        res.json(animals); // Return the results as JSON
    } catch (err) {
        res.status(500).json({ error: err.message }); // Handle errors
    }
});

// Serve frontend
app.use(express.static('public'));

// Test route to fetch one document (optional)
app.get('/test-one', async (req, res) => {
    try {
        const oneAnimal = await Animal.findOne({});
        res.json(oneAnimal);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});