package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// LoginActivity extends AppCompatActivity
public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton;
    private TextView createAccountLink, forgotPasswordLink;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // display activity_login.xml
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);

        // UI components and their corresponding layout elements
        usernameEditText = findViewById(R.id.enterUsername);
        passwordEditText = findViewById(R.id.enterPassword);
        loginButton = findViewById(R.id.btnSignIn);
        createAccountLink = findViewById(R.id.create_account_link);
        forgotPasswordLink = findViewById(R.id.forgot_password_link);

        loginButton.setOnClickListener(v -> handleLogin());
        createAccountLink.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, SignUpActivity.class)));
        forgotPasswordLink.setOnClickListener(v -> startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class)));
    }

    // handles user login
    private void handleLogin() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Check if the user exists
        Cursor userCursor = db.query("users", null, "username=?", new String[]{username}, null, null, null);

        if (userCursor != null && userCursor.getCount() == 0) {
            // User does not exist
            Toast.makeText(this, "User does not exist", Toast.LENGTH_SHORT).show();
            userCursor.close();
            return;
        }

        // Step 2: Validate credentials
        Cursor cursor = db.query("users", null, "username=? AND password=?", new String[]{username, password}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Successful login
            cursor.close();
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(LoginActivity.this, InventoryActivity.class));
            finish();
        } else {
            // Incorrect password
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }

        if (cursor != null) {
            cursor.close();
        }
    }

}
