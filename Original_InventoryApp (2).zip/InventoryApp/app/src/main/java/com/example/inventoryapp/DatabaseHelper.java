package com.example.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

//DatabaseHelper extends SQLiteHelper
public class DatabaseHelper extends SQLiteOpenHelper {

    // Constant and column names
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "id";
    private static final String COLUMN_ITEM_NAME = "name";
    private static final String COLUMN_ITEM_QUANTITY = "quantity";

    // Initialize the database helper with the app's context
    public DatabaseHelper(android.content.Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //  Creates the database tables if they do not already exist.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
        db.execSQL("CREATE TABLE inventory (id TEXT PRIMARY KEY, name TEXT, quantity INTEGER)");
    }

    //Handles database upgrades
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");
        onCreate(db);
    }

    // Add inventory item
    public boolean addInventoryItem(String id, String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_ID, id); // Ensure correct column
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1; // Return true if insertion was successful
    }

    // Delete inventory item
    public boolean deleteInventoryItem(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + "=?", new String[]{id});
        return rowsAffected > 0; // Return true if any rows were deleted
    }

    // Get all inventory items
    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem(
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY))
                );
                items.add(item);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return items;
    }

    // Statistic nested class for inventory item in the database
    public static class InventoryItem {
        private final String id;
        private final String name;
        private final int quantity;

        // Inventory item constructor
        public InventoryItem(String id, String name, int quantity) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
        }
        // Getter methods

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}
