package com.example.inventoryapp;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.appcompat.app.AlertDialog;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    // constant
    private static final int REQUEST_CODE_SEND_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // display activity_sms.xml
        setContentView(R.layout.activity_sms);
        // initialize button for granting permission
        Button requestPermissionButton = findViewById(R.id.grant_permission_button);

        // check if permission is already granted
        requestPermissionButton.setOnClickListener(v -> {
            showPermissionRequestDialog();
        });
    }

    // show permission request dialog
    private void showPermissionRequestDialog() {
        // ask user for permission
        new AlertDialog.Builder(this)
                .setTitle("Permission Needed")
                .setMessage("We need permission to send SMS notifications like low inventory alerts or upcoming events.")
                .setPositiveButton("Grant Permission", new DialogInterface.OnClickListener() {
                    // when user grants permission
                    public void onClick(DialogInterface dialog, int which) {
                        // Request the SEND_SMS permission from the user
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.SEND_SMS},
                                REQUEST_CODE_SEND_SMS);
                    }
                })
                // when user denies permission
                .setNegativeButton("No Thanks", null)
                .show();
    }
    // when user responds to the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // if request code is equal to the request code SMS
        if (requestCode == REQUEST_CODE_SEND_SMS) {
            // check is permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // display "Permission granted"
                Toast.makeText(this, "Permission granted.", Toast.LENGTH_SHORT).show();
                // move on to inventory screen
                Intent intent = new Intent(MainActivity.this,InventoryActivity.class);
                startActivity(intent);
                finish();
            } else {
                // display "Permission denied. You can enable SMS permission in app settings."
                Toast.makeText(this, "Permission denied. You can enable SMS permission in app settings.", Toast.LENGTH_LONG).show();
            }
        }
    }
}

