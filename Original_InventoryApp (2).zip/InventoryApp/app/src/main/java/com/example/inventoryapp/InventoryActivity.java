package com.example.inventoryapp;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;




import java.util.List;



// InventoryActivity extends AppCompatActivity
public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //display activity_inventory.xml
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);

        // Populate the inventory table when the activity loads
        populateInventoryTable();


        // Set up the "Add Item" button
        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(v -> showAddItemDialog());

        // Set up the "Delete Item" button
        Button deleteItemButton = findViewById(R.id.deleteItemButton);
        deleteItemButton.setOnClickListener(v -> showDeleteItemDialog());
    }

    // populate inventory table
    private void populateInventoryTable() {
        TableLayout tableLayout = findViewById(R.id.inventory_table);
        tableLayout.removeAllViews(); // Clear any existing rows

        // header row
        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(getResources().getColor(android.R.color.darker_gray)); // Header background

        // Create header cells for "Item ID" and "Quantity"
        // make layout
        TextView headerItemId = new TextView(this);
        headerItemId.setText("Item ID");
        headerItemId.setTextSize(18);
        headerItemId.setPadding(16, 16, 16, 16);
        headerItemId.setGravity(Gravity.CENTER);
        headerItemId.setBackgroundResource(R.drawable.cell_border);

        TextView headerQuantity = new TextView(this);
        headerQuantity.setText("Quantity");
        headerQuantity.setTextSize(18);
        headerQuantity.setPadding(16, 16, 16, 16);
        headerQuantity.setGravity(Gravity.CENTER);
        headerQuantity.setBackgroundResource(R.drawable.cell_border);

        //Add headers to the row and the row to the table
        headerRow.addView(headerItemId);
        headerRow.addView(headerQuantity);
        tableLayout.addView(headerRow);

        // get inventory items and display them
        List<DatabaseHelper.InventoryItem> items = dbHelper.getAllInventoryItems();
        for (DatabaseHelper.InventoryItem item : items) {
            TableRow row = new TableRow(this);

            // Make rows editable for both item id and quantity
            EditText itemIdView = new EditText(this);
            itemIdView.setText(item.getId());
            itemIdView.setTextSize(16);
            itemIdView.setPadding(16, 16, 16, 16);
            itemIdView.setGravity(Gravity.CENTER);
            itemIdView.setBackgroundResource(R.drawable.cell_border);

            EditText quantityView = new EditText(this);
            quantityView.setText(String.valueOf(item.getQuantity()));
            quantityView.setTextSize(16);
            quantityView.setPadding(16, 16, 16, 16);
            quantityView.setGravity(Gravity.CENTER);
            quantityView.setBackgroundResource(R.drawable.cell_border);

            row.addView(itemIdView);
            row.addView(quantityView);
            tableLayout.addView(row);
        }

        for (DatabaseHelper.InventoryItem item : items) {
            if (item.getQuantity() < 5) { // low stock threshold
                checkLowStockAndNotify(item.getName(), item.getQuantity());
            }
        }

        // Add a predefined number of empty rows (e.g., 10 rows)
        for (int i = 0; i < 30; i++) {
            TableRow emptyRow = new TableRow(this);

            EditText emptyItemId = new EditText(this);
            emptyItemId.setHint("");
            emptyItemId.setTextSize(16);
            emptyItemId.setPadding(16, 16, 16, 16);
            emptyItemId.setGravity(Gravity.CENTER);
            emptyItemId.setBackgroundResource(R.drawable.cell_border);

            EditText emptyQuantity = new EditText(this);
            emptyQuantity.setHint("");
            emptyQuantity.setTextSize(16);
            emptyQuantity.setPadding(16, 16, 16, 16);
            emptyQuantity.setGravity(Gravity.CENTER);
            emptyQuantity.setBackgroundResource(R.drawable.cell_border);

            emptyRow.addView(emptyItemId);
            emptyRow.addView(emptyQuantity);
            tableLayout.addView(emptyRow);
        }
    }

    // Notification alert for low stock items
    private void sendSmsNotification(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            // Placeholder number
            String phoneNumber = "1234567890";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Low stock alert sent successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // checks if stock is low and notifies user
    private void checkLowStockAndNotify(String itemName, int itemStock) {
        String message = "Low stock alert! " + itemName + " has only " + itemStock + " items left.";
        boolean isSmsPermissionGranted = getIntent().getBooleanExtra("isSmsPermissionGranted", false);
        // If user has granted permission
        if (isSmsPermissionGranted) {
            sendSmsNotification(message);
        } else {
            // else a toast message
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }
    }


     // displays a dialog for adding a new item to the inventory
     private void showAddItemDialog() {
         AlertDialog.Builder builder = new AlertDialog.Builder(this);
         builder.setTitle("Add New Item");

         // Inflate and set the custom layout for the dialog
         View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_item, null);
         builder.setView(dialogView);
        // Retrieve input fields from the dialog layout
         EditText itemIdEditText = dialogView.findViewById(R.id.item_name);
         EditText itemNameEditText = dialogView.findViewById(R.id.item_name);
         EditText itemQuantityEditText = dialogView.findViewById(R.id.item_quantity);
        // Behavior for add button
         builder.setPositiveButton("Add", (dialog, which) -> {
             String itemId = itemIdEditText.getText().toString().trim(); // Retrieve ID
             String itemName = itemNameEditText.getText().toString().trim();
             String itemQuantityStr = itemQuantityEditText.getText().toString().trim();

        // if empty
            if (TextUtils.isEmpty(itemId) || TextUtils.isEmpty(itemName) || TextUtils.isEmpty(itemQuantityStr)) {
                Toast.makeText(this, "Please enter Item ID, Name, and Quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            int itemQuantity = Integer.parseInt(itemQuantityStr);

            // toast when item is added or failed to add
            if (dbHelper.addInventoryItem(itemId, itemName, itemQuantity)) {
                Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                populateInventoryTable(); // Refresh the table
            } else {
                Toast.makeText(this, "Failed to add item. Duplicate ID?", Toast.LENGTH_SHORT).show();
            }
        });
         // cancel option
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());


        builder.create().show();
    }

    // Show a dialog to delete an existing item from the inventory
    private void showDeleteItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Item");

        // Inflate the custom dialog layout
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_delete_item, null);
        builder.setView(dialogView);

        EditText itemIdEditText = dialogView.findViewById(R.id.item_id);

        builder.setPositiveButton("Delete", (dialog, which) -> {
            String itemId = itemIdEditText.getText().toString().trim();

            // if empty
            if (TextUtils.isEmpty(itemId)) {
                Toast.makeText(this, "Please enter an Item ID", Toast.LENGTH_SHORT).show();
                return;
            }
            // toast when item is deleted or failed to delete
            if (dbHelper.deleteInventoryItem(itemId)) {
                Toast.makeText(this, "Item deleted successfully!", Toast.LENGTH_SHORT).show();
                populateInventoryTable(); // Refresh the table
            } else {
                Toast.makeText(this, "Failed to delete item. ID not found.", Toast.LENGTH_SHORT).show();
            }
        });

        //cancel option
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }


}
