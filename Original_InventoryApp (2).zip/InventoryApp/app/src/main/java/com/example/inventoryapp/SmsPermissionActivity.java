package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// SmsPermissionActivity extends AppCompatActivity
public class SmsPermissionActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_SEND_SMS = 1;
    private boolean isSmsPermissionGranted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestSmsPermission(); // Prompt the user to grant SMS permission
        } else {
            isSmsPermissionGranted = true; // Permission already granted
            navigateToInventoryScreen(); // Proceed to the main inventory screen
        }
    }


    // SMS permission request
    private void requestSmsPermission() {
        new AlertDialog.Builder(this)
                .setMessage("We need permission to send SMS notifications for low inventory alerts.") // explanation
                // button to grant permission
                .setPositiveButton("Grant Permission", (dialog, which) -> ActivityCompat.requestPermissions(
                        SmsPermissionActivity.this,
                        new String[]{Manifest.permission.SEND_SMS},
                        REQUEST_CODE_SEND_SMS
                ))
                // button to deny
                .setNegativeButton("No Thanks", (dialog, which) -> navigateToInventoryScreen())
                .show();
    }

    // permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_SEND_SMS) {
            isSmsPermissionGranted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            String message = isSmsPermissionGranted
                    ? "Permission granted for SMS notifications."
                    : "Permission denied. SMS notifications will be disabled.";
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

            navigateToInventoryScreen();
        }
    }

    // redirect to inventory screen
    private void navigateToInventoryScreen() {
        Intent intent = new Intent(SmsPermissionActivity.this, InventoryActivity.class);
        intent.putExtra("isSmsPermissionGranted", isSmsPermissionGranted);
        startActivity(intent);
        finish();
    }
}



