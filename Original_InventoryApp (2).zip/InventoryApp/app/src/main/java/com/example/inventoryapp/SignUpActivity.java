package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//SignUpActivity extends AppCompatActivity
public class SignUpActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button createAccountButton;
    private TextView backToLoginLink;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // display activity_signup.xml
        setContentView(R.layout.activity_signup);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

       // UI components and their corresponding layout elements
        usernameEditText = findViewById(R.id.crtUsername);
        passwordEditText = findViewById(R.id.crtPassword);
        createAccountButton = findViewById(R.id.btnCreateAcc);
        backToLoginLink = findViewById(R.id.sign_in_link);

        createAccountButton.setOnClickListener(v -> handleSignUp());
        backToLoginLink.setOnClickListener(v -> startActivity(new Intent(SignUpActivity.this, LoginActivity.class)));
    }

    // handles sign up
    private void handleSignUp() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // toast if fields are empty
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        //
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        // Store the username and password in the database
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        // Check if the account creation was successful
        if (result != -1) {
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            // Redirect the user to the login screen
            startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
        }
    }
}
